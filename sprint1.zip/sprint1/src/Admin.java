
public class Admin {
	//takes an unverified driver and verifies them then changes their verified value to true if they have valid data or removes them from the pending list
	public void verify(Driver driver) {
		
	}
	//retrieves all the drivers with verified values equal to false and call the verify method on each of them
	public void listPendings() {
		
	}
}
